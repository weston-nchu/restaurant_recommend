import jwt
import json
from typing import TypeVar
from fastapi import Depends, HTTPException, status
from datetime import datetime, timedelta, timezone
from .database.user import User
from .user_role import UserRole
from .base_object import Auth
from fastapi.security import OAuth2PasswordBearer
from .yml_utils import YmlUtils

config = YmlUtils("app.yml")

U = TypeVar("U", bound=User)

R = TypeVar("R", bound=UserRole)

# JWT secret key
secret_key = config.get_val("security.jwt.secret-key")

# JWT algorithm
code_algorithm = "HS256"

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/login")

def gen_jwt(user: U) -> Auth:
    """
    生成 JWT token

    args:
        user(U): user object, U should extands pyfk.User

    return:
        Auth
    """
    # 主體資料
    sub = {
        "uid": user.uid,
        "roles": user.roles
    }
    payload = {
        "sub": json.dumps(sub),
        "exp": datetime.now(timezone.utc) + timedelta(days=3) # 時效3天
    }
    token = jwt.encode(payload, secret_key, algorithm=code_algorithm)
    return Auth(access_token=token)

def verify(*roles: R) -> str:
    """
    security 驗證
    1. JWT 驗證 
    2. roles 驗證

    args:
        roles(List[R]): endpoint roles, R should extands pyfk.Role

    return:
        str: user uid
    """
    # JWT 驗證
    def decode_jwt(token: str = Depends(oauth2_scheme)):

        try:
            payload = jwt.decode(token, secret_key, algorithms=[code_algorithm])
            user = json.loads(payload["sub"])
        except jwt.ExpiredSignatureError:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="token has expired.")
        except jwt.InvalidTokenError:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="token is invalid.")
        
        # roles 驗證
        def verify_roles():
            # 驗證role
            if roles and not any(role.name in user["roles"] for role in roles):
                raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="access denied.")
            return user["uid"]
        
        return verify_roles()
    
    return decode_jwt