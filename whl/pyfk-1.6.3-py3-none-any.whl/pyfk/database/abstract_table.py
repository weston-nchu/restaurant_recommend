import uuid
import random
from .session import Base
from sqlalchemy import *
from datetime import datetime, date

class AbstractTable(Base):

    __abstract__ = True

    # uuid
    uid = Column(String(length=32), primary_key=True, index=True)

    # 建立時間
    create_time = Column(DateTime, nullable=False)

    # 最後更新時間
    lm_time = Column(DateTime, nullable=False)

    # 最後更新使用者
    lm_user = Column(String(length=50), nullable=False)

    def __init__(self, lm_user = "system") -> None:
        self.uid = self.__gen_uuid()
        self.lm_user = lm_user
        self.create_time = datetime.now()
        self.lm_time = datetime.now()

    def __repr__(self) -> str:
        class_name = self.__class__.__name__
        columns = self.__table__.columns.keys()
        str_tmp = []
        for c in columns:
            str_tmp.append(f"{c}='{getattr(self, c)}'")
        return "<%s(%s)>" % (class_name, ", ".join(str_tmp))

    def get_create_time_strf(self) -> str:
        return "" if not self.create_time else self.create_time.strftime("%Y/%m/%d %H:%M:%S")

    def get_lm_time_strf(self) -> str:
        return "" if not self.lm_time else self.lm_time.strftime("%Y/%m/%d %H:%M:%S")

    def __gen_uuid(self):
        return str(uuid.uuid3(uuid.NAMESPACE_DNS, str(datetime.now().timestamp()) + str(random.random()))).replace("-", "")
