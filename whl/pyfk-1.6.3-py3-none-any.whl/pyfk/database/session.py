from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from pyfk.yml_utils import YmlUtils
from sqlalchemy.pool import NullPool

config = YmlUtils("app.yml")

active = config.get_val("database.active")
if not active:
    active = "dev"
dialect = config.get_val(f"database.application.{active}.dialect")
server = config.get_val(f"database.application.{active}.server")
port = config.get_val(f"database.application.{active}.port")
database = config.get_val(f"database.application.{active}.database")
username = config.get_val(f"database.application.{active}.username")
password = config.get_val(f"database.application.{active}.password")
driver = config.get_val(f"database.application.{active}.driver")
show_sql = config.get_val(f"database.application.{active}.show-sql")

Base = declarative_base()

engine_url = f"sqlite:///{database}"
engine = create_engine(engine_url, echo=show_sql, poolclass=NullPool, pool_recycle=3600)
session_local = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_db_session():
    db = session_local()
    try:
        yield db
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def create_table():
    Base.metadata.create_all(engine, checkfirst=True)
