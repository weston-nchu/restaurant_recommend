from typing import Any, Generic, List, TypeVar
from pyfk import AbstractTable
from sqlalchemy import *
from datetime import date
from pyfk.gender import Gender
from pyfk.role import Role
from pyfk.user_status import UserStatus
from pyfk.user_role import UserRole
from pyfk import password_hasher
from email_validator import validate_email

R = TypeVar("R", bound=Role)

class User(AbstractTable, Generic[R]):
    """
    使用者

    author: weston
    """

    # 預設user role toye 為 UserRole
    role_type: R = UserRole

    __tablename__ = "user"

    # 信箱
    email = Column(String(length=64), nullable=False, unique=True)

    # 密碼(SHA3-256加密)
    hashed_password = Column(String(length=256), nullable=False)

    # 姓名
    name = Column(String(length=64), nullable=False)

    # 性別
    gender = Column(Enum(Gender), nullable=False)

    # 聯絡電話
    phone = Column(String(length=16), nullable=False)

    # 生日
    birth = Column(Date, nullable=False)

    # 帳號狀態: UserStatus
    status = Column(Enum(UserStatus), nullable=False, default=UserStatus.UNVERIFIED)

    # 角色
    roles = Column(String(length=64), nullable=False)

    def __init__(self, email: str, password: str, name: str,
            gender: Gender, phone: str, birth: date, lm_user = "system") -> None:
        super().__init__(lm_user)
        self.email = validate_email(email).original
        self.hashed_password = password_hasher.sha3_256(password)
        self.name = name
        self.gender = gender
        self.phone = phone
        self.birth = birth
    
    def __init_subclass__(cls, **kwargs: Any):
        super().__init_subclass__(**kwargs)
        for base in cls.__orig_bases__:
            if hasattr(base, "__args__"):
                cls.role_type = base.__args__[0]
                break

    def set_roles(self, *roles: R):
        """
        setting user roles

        args:
            *roles(tuple[R]): user roles, R should extands pyfk.Role
        """
        self.roles = ",".join([r.name for r in roles])

    def get_roles(self) -> List[R]:
        """
        convert User.roles(str) to List[R] and return

        return:
            List[R]
        """
        return [getattr(self.role_type, r) for r in self.roles.split(",")]