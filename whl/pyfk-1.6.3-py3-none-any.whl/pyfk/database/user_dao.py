from pyfk import CrudSql
from sqlalchemy.orm.session import Session
from .user import User
from pyfk import password_hasher

class UserDao(CrudSql[User]):
    """
    專屬於 User 的 DAO, 如需繼承 pyfk.User, 其 DAO 需繼承 CrudSql 並複製 get_user function.

    ex:
        class CustomUserDao(CrudSql[CustomUser]):
            
            def __init__...

            def get_user(self, email: str, password: str) -> CustomUser:
                return self.get_one(email=email, hashed_password=password_hasher.sha3_256(password))
    """

    def __init__(self, db: Session = None):
        super().__init__(db)

    def get_user(self, email: str, password: str) -> User:
        return self.get_one(email=email, hashed_password=password_hasher.sha3_256(password))
