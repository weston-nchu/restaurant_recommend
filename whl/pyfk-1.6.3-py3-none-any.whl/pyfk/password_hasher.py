import hashlib

def sha3_256(password: str) -> str:
    password_bytes = password.encode("utf-8")
    sha3_256_hasher = hashlib.sha3_256()
    sha3_256_hasher.update(password_bytes)
    hashed_password = sha3_256_hasher.hexdigest()
    return hashed_password