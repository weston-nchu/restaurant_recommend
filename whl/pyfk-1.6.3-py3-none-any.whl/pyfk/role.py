from enum import Enum

class Role(Enum):

    pass