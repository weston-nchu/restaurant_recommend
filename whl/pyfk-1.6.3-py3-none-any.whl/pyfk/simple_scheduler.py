from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler import events
from .log_factory import get_logger

class SimpleScheduler(BackgroundScheduler):
    """
    繼承apscheduler.schedulers.background.BackgroundScheduler

    加入2個listener
    1. start_handler: 當排程開始執行時印出 "Scheduler job {scheduler.id} run started"
    2. success_handler: 當排程執行完畢後且無錯誤印出 "Scheduler job {scheduler.id} run finished"
    3. except_handler: 當排程執行中發生錯誤時印出 "Run job {scheduler.id} has except: {exception}"

    author: weston
    """

    def __init__(self, logger: str = "", gconfig={}, **options):
        super().__init__(gconfig=gconfig, **options)
        self.log = get_logger(logger)
        self.add_listener(self.start_handler, events.EVENT_JOB_SUBMITTED)
        self.add_listener(self.success_handler, events.EVENT_JOB_EXECUTED)
        self.add_listener(self.except_handler, events.EVENT_JOB_ERROR)

    def start_handler(self, e):
        jb = e.job_id
        self.log.info("Scheduler job [%s] run started" % jb)

    def success_handler(self, e):
        jb = e.job_id
        self.log.info("Scheduler job [%s] run finished" % jb)
        
    def except_handler(self, e):
        jb = e.job_id
        ext = e.exception.__class__.__name__
        ex = str(e.exception)
        tb = e.traceback
        self.log.error("Run job [%s] has except %s: %s \n Traceback: \n %s" % (jb, ext, ex, tb))
