from .role import Role

class UserRole(Role):
    """
    user role
    """

    # 管理員
    ADMIN = "ADMIN"

    # 操作員
    OPERATOR = "OPERATOR"

    # 使用者
    USER = "USER"