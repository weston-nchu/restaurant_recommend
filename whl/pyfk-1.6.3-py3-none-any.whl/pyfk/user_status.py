from enum import Enum

class UserStatus(Enum):

    # 未驗證
    UNVERIFIED = "UNVERIFIED"

    # 啟用
    ENABLED = "ENABLED"

    # 停用
    DISABLED = "DISABLED"